
#include "String.h"

//the main fuction, used to test my code

int main()
{
	test();
	system("pause");
	return 0;
}

